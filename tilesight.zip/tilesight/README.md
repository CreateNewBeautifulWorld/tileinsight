# tilesight — tile-centric analytical GPU performance model + LLM simulator

Re-implementation of **TileSight** (arXiv 2607.22432) with a model layer on top:
give a model's layer sizes (or a HF `config.json`), a hardware YAML and a run config →
per-GPU step latency, tok/s/GPU, per-op tiles and limiters, HBM footprint, and
design-space sweeps over any hardware field.

Python front-end (config, lowering, reports) · C++17 core via nanobind (engine + L2 model),
bit-identical to the Python reference engine.

```bash
pip install -e ".[dev]"            # or: cmake -S . -B build && cmake --build build -j
PYTHONPATH=python pytest -q
PYTHONPATH=python python -m tilesight.cli run --model kimi_k2.hf --hw b300 \
    --phase decode --batch 256 --seq 8192 --dp 8
PYTHONPATH=python python -m tilesight.cli request --model kimi_k2.hf --hw b300 --batch 256 --dp 8 \
    --prompt 8192 --output 4096            # TTFT, TPOT curve, peak memory, max concurrency
PYTHONPATH=python python -m tilesight.cli sweep --model kimi_k2.hf --hw b300 --phase decode \
    --batch 256 --seq 8192 --dp 8 --param memory.ddr.bandwidth_TBps --values 4,8,12,16
PYTHONPATH=python python -m tilesight.cli need --model kimi_k2.hf --hw b300 --phase decode \
    --batch 256 --seq 8192 --dp 8 --param memory.ddr.bandwidth_TBps --target-ms 25
PYTHONPATH=python python -m tilesight.cli dump-model --model kimi_k2.hf > my_model.yaml   # edit sizes
PYTHONPATH=python python examples/sweep_ddr_bw_b300.py
```

## Web UI (compute stays on your machine)
```bash
PYTHONPATH=python python -m tilesight.cli serve --host 0.0.0.0 --port 8000
```
Open `http://<your-machine>:8000`. The page is a **single self-contained HTML file**
(no CDN, no fonts, no external requests) served by a stdlib HTTP server — clients only need
a browser; every evaluation runs on the serving machine with the C++ engine.

- Modes: **single GPU (one kernel + tile study)** / single step / request (prompt+output) /
  hardware sweep / required-value bisection.
- Single-GPU mode: pick the card (b300 / b200 / h200, plus dotted overrides), pick a kernel
  (GEMM, grouped/MoE GEMM, attention decode, attention prefill, elementwise), enter the shapes,
  and get latency, TFLOP/s, % of the dtype peak, HBM traffic, occupancy (`1/smem+regs`),
  L2 miss ratio and the bound (`tc:mma`, `ddr:load:expert_weight`, `latency:softmax(sfu)`),
  with the ranked tile candidates behind it. No TP/DP/EP, no collectives.
- Config: model preset **or pasted layer-size YAML / HF config**, hardware preset + dotted
  overrides (`{"memory.ddr.bandwidth_TBps": 12}`), phase, batch, seq, prompt/output, TP/DP/EP,
  dtypes, attention impl, tile policy and per-op tile overrides.
- Datatypes: **int4 · nvfp4 · fp4 · fp8 · int8 · bf16 · fp16 · fp32** (+ mxfp4/mxfp6/mxfp8/tf32 aliases).
  `int4` is weight-only (MMA at the activation width, half the weight traffic); a dtype with no
  tensor-core datapath on the chosen card widens to the next one it has (fp4 → fp8 on Hopper/CDNA3);
  fp32 falls back to the CUDA/vector cores.
- Jobs are asynchronous: the UI polls `/api/jobs/<id>` and shows **"Processing… 12/38 · op name · 1.4s"**
  with a progress bar, so a long sweep never looks frozen.
- API (JSON): `GET /api/options`, `POST /api/jobs {mode, config}`, `GET /api/jobs/<id>`.
  CORS is open, so you can also open the HTML from `file://` and point it at the server.

Cost per request on one CPU core (Kimi-K2, 8×B300): single step ≈ 0.35 s, request mode ≈ 0.6 s,
6-point sweep ≈ 1.4 s, bisection (18 evals) ≈ 5 s. Repeat runs hit the lowering cache and are
faster. For many concurrent users, run several server processes behind a reverse proxy — Python
lowering holds the GIL, so one process serializes CPU-bound jobs.

## Inputs
- **Model** (`model/spec.py`): block-level YAML (`mha`, `gqa`/MQA, `mla`, `mlp`, `moe`,
  `norm`, raw `gemm`/`elementwise`) with `repeat` per layer group, or a HF config (presets:
  `kimi_k2.hf` MLA, `llama3_70b.hf` GQA, `llama2_7b.hf` MHA). Every attention block takes
  `impl: flash|naive`, `causal`, `sliding_window` (+ `absorb` for MLA). See
  `examples/custom_model.yaml`, `examples/attention_variants.yaml`.
- **Hardware** (`hw/db/*.yaml`): NVIDIA **B300** (default), **B200**, **H200**; AMD **MI300X**,
  **MI325X**, **MI355X**, **MI450** (CDNA3/4/5 — `sms` = CUs, on-chip `smem` = LDS, `l2` = Infinity
  Cache/MALL, no TMA/TMEM/clusters, load paths `tdm`/`buffer_lds`/`lsu`). Every field is overridable by
  dotted path (`--set memory.ddr.bandwidth_TBps=12`). New on-chip memories / load paths
  become resource lanes automatically.
- **Run config** (`examples/run_decode.yaml`): phase, batch, seq, tp/dp/ep, dtypes, tile
  policy (`auto`, fixed, or per-op fnmatch overrides like `"*.experts_*": {bm: 64, bn: 256}`),
  `attn_impl: flash|naive` default for all attention blocks.

## Outputs
- Step time / TPOT, tok/s/GPU; request mode: TTFT, TPOT first/last/avg over the KV growth
  from prompt to prompt+output, end-to-end latency.
- **Where it is bound**: by resource class (tensor core, CUDA core, SFU, SMEM, TMEM,
  registers/spill, L2, DDR/HBM, load path, interconnect, latency, launch) and by
  resource:tensor (e.g. `ddr:load:expert_weight`, `ddr:load:kv_cache(latent)`,
  `latency:softmax(sfu)`), plus the occupancy limiter per kernel (`1/smem+regs`, `2/tmem`).
- Memory: weights / KV / activations / reserve, **peak** over the generation, paged KV,
  max concurrent requests per rank. CSV export.

## Snapshot: Kimi-K2 decode, 8× B300 (dp=8, ep=8, FP8), batch 256, 8K context, L2 BW scaled 2.56× DDR
| DDR TB/s | TPOT ms | tok/s/GPU | top limiter | DDR share |
|---|---|---|---|---|
| 4 | 54.5 | 588 | ddr | 86% |
| 6 | 38.8 | 824 | ddr | 80% |
| 8 (B300) | 31.1 | 1,030 | ddr | 73% |
| 12 | 24.0 | 1,331 | ddr | 54% |
| 16 | 20.6 | 1,557 | ddr | 46% |
| 24 | 17.9 | 1,792 | l2 (per-SM load cap) | 1% |

Above ~20 TB/s the wall moves to the per-SM global-load cap (`memory.l2.per_sm_max_GBps`,
a calibration placeholder), then latency/launch — raising HBM alone stops paying off.
**All `[calib]` numbers are placeholders until the calibration suite (docs/TASKS.md
Phase C) runs on real hardware; treat absolute values as indicative, trends as the result.**

Docs:
- `CLAUDE.md` — how to work in this repo (for Claude Code)
- `docs/DESIGN.md` — equations, semantics, deviations from the paper
- `docs/TASKS.md` — ordered backlog with acceptance criteria (Phase H = items from research report 02)
- `docs/research/01_reimplementation_plan.md` — paper summary + re-implementation plan
- `docs/research/02_accuracy_tuning_presets_kimi_k3.md` — paper accuracy & caveats, "what to tune
  if inaccurate" guide, GB300 / H200 / MI450 specs, Kimi-K3 config, single-GPU vs system split

# DESIGN — equations, semantics, deviations

## 1. Layers
```
ModelSpec (blocks: mla/gqa/mlp/moe/norm/raw)      model/spec.py      <- user gives layer sizes / HF config
   │  RunConfig (phase, batch, seq, tp/dp/ep, dtypes, tile policy)
   ▼
Ops for one GPU (gemm, attn_decode, attn_prefill, elementwise, allreduce, a2a)   model/lower.py
   │  tile policy: fixed | per-op override (fnmatch) | auto search (kernels/tiles.py)
   ▼
Kernels = tile execution plans lowered to numbers (ir/kernel.py)   kernels/*.py
   │  HardwareSpec -> lanes
   ▼
Engine (reference.py == C++ core) -> KernelResult (time, limiter, util)
   ▼
ModelReport: step time, tok/s/GPU, per-op table, limiter mix, memory   model/runner.py
DSE: sweep / required_value over any hardware field                      dse/sweep.py
```

## 2. Hardware → resource lanes (paper Eq. 1, generalized)
The paper's fixed vector ⟨TC, CUDA, SFU, TMEM, SMEM, L1.5, L2, DDR, Net⟩ becomes a
**named, data-driven lane list** built from the YAML:

| lane | source | work unit in Action.work | rate |
|---|---|---|---|
| `tc` | compute.tc_dense_tflops[dtype] | seconds on one SM | peak·eff/SMs |
| `cuda` | compute.cuda_fp32_tflops | seconds on one SM | |
| `sfu` | compute.sfu_tops | seconds on one SM | |
| `<onchip>` (smem, tmem, …) | memory.onchip.* | seconds on one SM | bytes/clk or TB/s per SM |
| `path:<p>` (tma, lsu, …) | load_paths.* | seconds on one SM | per_sm_GBps |
| `l2` | memory.l2 | **bytes** | min(BW·eff / active_SMs, per_sm_max) |
| `ddr` | memory.ddr | **bytes** | min(BW·eff / active_SMs, per_sm_max) |

Shared lanes model the paper's observation that a partially filled wave gives each
active SM a larger share of L2/DDR bandwidth, bounded by what one SM can pull
(`per_sm_max_GBps`, a calibration target). Net is handled by comm kernels (§5.4).

### 2b. Datatypes
`DTYPE_BYTES` gives storage width; `DTYPE_ALIAS` maps a name to the tensor-core datapath it runs on
(nvfp4/mxfp4 → fp4, mxfp8 → fp8); `WEIGHT_ONLY` (int4) means the weights are narrow but the MMA runs
at the activation width. `HardwareSpec.tc_datapath` widens to the next datapath a part actually has
(fp4 → fp8 on Hopper/CDNA3); `mma_cost` returns the `cuda` lane when there is no tensor-core path at
all (fp32). Capability flags gate tile features: `compute.cta_pair` (2-CTA MMA),
`compute.cluster_multicast` (thread-block clusters + TMA multicast; false on AMD),
`load_paths_default` (a request for `tma` resolves to the part's real path, e.g. CDNA5 `tdm`).

## 3. Engine (paper §3.3–3.4, Eqs. 2–5; Algorithms 1–2)
For a kernel with `num_blocks`, `iters`, `stages`, `resident`, `consumers` and action
lists `prologue`, `body` (one K-loop iteration), `epilogue`:

**Waves.** `conc = SMs·resident`; `full, tail = divmod(num_blocks, conc)`. For a wave of
`b` blocks: `active = min(SMs, ⌈b/resident⌉)`, `bps = ⌈b/active⌉`.

**Per-action lane time.** `u_r(o) = work_r(o)` (per-SM lane) or `work_r(o)/share_r(active)`
(shared lane). Node weight `w(o) = max_r u_r(o) + latency(o)`.

**Steady round (Eq. 4').**
```
R = max( bps · max_r Σ_o u_r(o)            # contention: same-lane work serializes (paper Eq. 4)
         CP / stages,                       # SMEM-buffer recycling recurrence
         CPrec / consumers )                # loop-carried compute recurrence
CP    = longest path over the body DAG with weights w(o)
CPrec = longest path using only actions flagged `recurrent`
```
Limiter label = the lane attaining the first term, else `latency`.

**Wave time (Eq. 2').** `T = T_pro + T_fill + iters·R + T_epi`, with
`T_fill = max(0, CP − R)` (first iteration's exposed latency) and
`T_pro/T_epi = max(bps·max_r Σ u_r, longest path)` over the prologue/epilogue lists.
Kernel time = Σ_waves count·T + launch overhead.

**Utilization.** busy fraction per lane = total work of all blocks / (machine rate × time).

**Bound attribution (coarse + fine).** Every phase's time is charged to a limiter:
- coarse (`limiter_time`): lane name | `latency` | `launch` | `net`
- fine (`limiter_detail`):
  - resource-bound → `"<lane>:<action>"`, action = the one putting most work on that lane,
    e.g. `ddr:load:expert_weight`, `l2:load:act`, `smem:mma`, `tc:gemm_qk`, `sfu:softmax`
  - latency-bound → `"latency:<action>(<lane>|mem-lat)"`, action = heaviest node on the
    critical path of whichever recurrence set the bound (CP/stages or CPrec/consumers),
    lane = that node's dominant lane or `mem-lat` if its memory latency dominates
  - `latency:fill`, `launch`, `net:<algo>`
Action names carry the **tensor** (`load:weight`, `load:kv_cache(K)`, `load:scores(S)`,
`store:partials`, `spill:regs` …), set by the lowering from `names=(A,B,C)`.
Reports roll details up into resource classes (compute:tensor-core / cuda-core / sfu,
on-chip:smem / tmem / regs(spill), cache:L2, memory:DDR/HBM, load-path:*, interconnect,
latency<-x, launch-overhead) and list the top resource:tensor pairs.

**Deviations from the paper (documented, switchable later — TASKS A1/A2):**
- Paper Eq. 5 minimizes over topological orders of the action DAG. We use a
  recurrence-based bound (CP/stages, CPrec/consumers) that is order-free; exact
  order enumeration is task A1 (needed for fused kernels with several independent
  chains, e.g. the paper's MLA-decode example with 132 legal orders).
- Paper Eq. 2 uses `N−d` steady iterations with `d = stages·resident−1`; we use all
  `iters` and an explicit fill term. This avoids the double-count the paper's reviewers
  suspected as the source of its deep-K bias. Task A2 adds the paper form behind a flag.

## 4. L2 model (paper §3.5, Eqs. 6–10)
Each lowering emits the tile access sequence of the **first wave** for up to 4 sampled
K-steps, in issue order (blocks progress in lock-step, swizzled raster order). Keys
encode (tensor, reuse coordinates) exactly as Eq. 6 (reuse dims dropped).
- `D_T` = distinct tiles between consecutive uses of the same tile (Fenwick tree, exact).
- `P(hit | D_T) = P(X ≤ A−1)`, `X ~ Bin(D_T, A/B_T)`, A = assoc, B_T = effective capacity
  / avg tile bytes. Exact binomial for D_T ≤ 256, else Gaussian with Zelen–Severo Φ and
  a +0.5 continuity correction (deviation: the paper writes 1−Q(|A−1−μ|/σ)).
- Compulsory first touches miss. Miss ratio per stream sets `ddr` bytes of each load;
  all load bytes go through `l2`.
- Load latency = path issue latency + hit·L2 latency + miss·DDR latency.
Not yet: cross-wave reuse (B1), L1.5 / per-die cascade (B2), D_T perturbation (A6).

## 5. Kernel lowerings
### 5.1 GEMM (`kernels/gemm.py`)
`C[b] = A[b]·B[b]`, grid `batch·⌈M/bm⌉·⌈N/bn⌉·split_k`, `iters = ⌈⌈K/bk⌉/split_k⌉`.
- stages: explicit or max fitting SMEM (≤8); resident = min over max_blocks, SMEM, threads,
  registers (GPR), TMEM; the report shows `resident/limiter`, all binding resources joined
  with `+` (e.g. `1/smem+regs`).
- **Registers (GPR)**: regs/thread = 40 base + fp32 accumulator spread over consumer
  threads (no-TMEM parts) or +16 epilogue regs (TMEM parts). Above
  `occupancy.max_regs_per_thread` the excess spills: `spill:regs` action charges
  2×spilled bytes per block to the L2 lane (spread over iterations).
- body: `load_A`, `load_B` (TMA/LSU/split paths), `mma` (tc time with M padded to
  `tc_min_m`; smem operand reads). Cluster multicast `cluster_m` divides B's L2 traffic;
  `cta_pair` (2-CTA MMA, capability `compute.cta_pair`) also halves B's SMEM footprint/reads.
- epilogue: TMEM accumulator read + convert, store C (fp32 partials if split-K, followed
  by a reduce kernel).
- low-precision datapath ⇒ activations are quantized to it (quant kernel cost: TASK E5).
### 5.2 Attention (`kernels/attention.py`)
- decode: block = (batch, kv_head, head-group of ≤block_m heads, kv-split); per KV tile:
  load K(/V) → gemm_qk → softmax (SFU exp + CUDA + TMEM S/P traffic) → gemm_pv;
  qk/softmax/pv are `recurrent`; `consumers` ping-pong warpgroups hide the chain.
  MLA absorbed: `d_qk = kv_lora+rope`, `d_v = kv_lora`, one kv head, `v_in_k`.
  auto split-KV fills the machine; a combine kernel follows.
- prefill: causal FA-style; iterations averaged over q-tiles (per-block iters: TASK A3).
### 5.2b Attention families and implementations (`model/attention_blocks.py`)
Three block types, all with `impl: flash | naive` (default `RunConfig.attn_impl`),
`causal`, `sliding_window`:

| block | shape fields | KV cache / token / layer (one GPU) | core |
|---|---|---|---|
| `mha` | heads, head_dim [, v_head_dim] | `heads/tp · (hd+vd) · kv_bytes` | H=KVH |
| `gqa` | heads, kv_heads, head_dim (kv_heads=1 → MQA) | `max(1,kv_heads/tp) · (hd+vd) · kv_bytes` | H/KVH query heads per KV head |
| `mla` | q_lora_rank, kv_lora_rank, qk_nope, qk_rope, v_head | `(kv_lora+rope) · kv_bytes` (replicated over tp) | absorbed: 1 latent KV head, d_qk=kv_lora+rope, d_v=kv_lora; expanded: MHA with d_qk=nope+rope, d_v=v_head |

Extra mha/gqa options: `fused_qkv`, `qk_norm`, `rope_dim`; MLA: `absorb: auto|true|false`.

**flash** → one fused kernel (§5.2): S/P never leave the SM; causal and sliding-window
tiles are skipped (per-q-tile iteration counts; average used until TASK A3).

**naive** → three ops, each a normal kernel lowering:
```
attn_scores : GEMM  M=(H/KVH)·Sq, N=Skv, K=d_qk, batch=B·KVH, out=attn_scores_dtype (fp32)
attn_softmax: elementwise  read S (fp32), write P (act dtype), 1 exp + ~5 flops / element
attn_pv     : GEMM  M=(H/KVH)·Sq, N=d_v, K=Skv, batch=B·KVH
```
Query heads sharing a KV head are folded into M so K/V are read once per KV head (the
GEMM's L2 model keys operands by batch index). Causal masking does not skip work.
S and P are counted as live activations → long-context naive prefill shows up as
activation-memory OVERFLOW and a `ddr`-bound softmax.

### 5.3 Elementwise
bytes in/out + CUDA flops + SFU ops, 32 KB chunks per block, LSU path.
### 5.4 Collectives (`kernels/comm.py`, Eq. 11)
allreduce: min(ring `2(p−1)α + 2(p−1)/p·S/β`, recursive doubling `⌈log2 p⌉(α+S/β)`).
all-to-all: `⌈log2 p⌉α + S·(p−1)/p/β`. NVLink inside `domain_size`, scale-out NIC beyond.
`RunConfig.comm_overlap` hides a fraction (placeholder for a real overlap scheduler, E2).

## 6. Model layer semantics (`model/lower.py`)
- Attention: `dp` groups of `tp` GPUs; heads split by tp; tokens per attention rank
  `T = batch/dp` (decode) or `batch/dp·seq` (prefill). MLA latent KV is replicated across
  tp ranks (not head-sharded).
- MLA: decode uses weight absorption (W_UK/W_UV as per-head batched GEMMs, attention
  over the 576-dim latent); prefill uses the non-absorbed path (kv_b up-projection, MHA
  with d_qk=192, d_v=128). Override with `RunConfig.mla_absorb`.
- Dense MLP / shared expert: column+row split by tp, all-reduce over tp.
- MoE: EP over `ep` GPUs (default all). Unique tokens per GPU `Tu = T/tp`. Pairs landing
  in the EP group `Tu·ep·k`; P(expert active) = `1−(1−k/E)^(Tu·ep)`; active local experts
  `E/ep·P`; tokens per active expert `Tu·ep·k/E/P`. Grouped GEMM batch = active experts —
  this is what makes small-batch decode stream (almost) all expert weights. Uniform
  routing is assumed (skew: TASK E7).
- lm_head: vocab/tp, only the last token per sequence.

## 7. Memory model (`model/memory.py`)
weights (per-op resident bytes × repeat, with sharding) + KV cache (per family, see §5.2b;
sliding-window layers store only `min(seq, window)` tokens) × seqs/rank + 2× peak live
activation + runtime reserve (4 GB, calib). Reports fit/overflow and max seqs per rank.

## 7b. Request-level runs (`model/request.py`)
Config: `prompt_len` (P), `output_len` (O), `page_size`, `kv_reserve: peak|current`,
`decode_samples`, `prefill_batch`.
- TTFT = prefill step over P tokens (`prefill_batch` sequences).
- Decode step t has KV length P+t. The full model is evaluated at `decode_samples`
  values of t in [1, O]; TPOT(t) is integrated with the trapezoid rule
  (avg TPOT = Σ/O; attention cost is linear in KV length, weights constant).
- E2E = TTFT + O·avg TPOT.
- KV per request at step t = kv_bytes_per_seq(ceil((P+t)/page)·page) (sliding-window
  layers capped at the window). Peak KV = at t=O. Peak total = weights + peak KV +
  max(prefill act, decode act) + reserve (conservative).
- max concurrent requests/rank = free HBM / per-request KV (peak: P+O; current: P+O/2).

## 8. DSE (`dse/sweep.py`)
`sweep(path, values, linked=f)` re-runs the model per value (kernels are re-lowered, so
tile auto-search re-adapts to the new hardware — important for fair comparisons).
`required_value` bisects the smallest value meeting a step-time target (assumes
monotonicity, which tests enforce for bandwidth knobs). Typical linked knobs: L2 BW ∝ DDR
BW; `memory.l2.per_sm_max_GBps` (otherwise it becomes the wall above ~25 TB/s on B300).

## 9. Known limitations
No warp-level issue model, no register allocation, no instruction-level scheduling
(same as the paper). Expert-load imbalance, MTP/speculative decoding, paged-KV page
effects, quantization kernels, chunked prefill and real compute–comm overlap are
backlog items (docs/TASKS.md). All `[calib]` constants are placeholders until the
calibration suite runs on real hardware.

"""Evaluate a model on a hardware spec: ops -> kernels (tile policy) -> engine -> report."""
from __future__ import annotations

import fnmatch
from dataclasses import dataclass, field

from ..engine import backend
from ..hw.spec import HardwareSpec
from ..ir.kernel import Kernel, KernelResult
from ..kernels import comm
from ..kernels.attention import lower_attention_decode, lower_attention_prefill
from ..kernels.gemm import lower_elementwise, lower_gemm
from ..kernels.tiles import AttnTileConfig, TileConfig, attn_search_space, gemm_search_space
from .lower import Op, lower_model
from .memory import MemoryReport, memory_report
from .run_config import RunConfig
from .spec import ModelSpec


@dataclass
class OpResult:
    op: Op
    group: str
    repeat: int
    kernels: list[KernelResult]
    tile: str

    exposed: float = 1.0           # <1 for collectives partly hidden by compute (rc.comm_overlap)

    @property
    def time_s(self) -> float:
        return sum(k.time_s for k in self.kernels) * self.exposed

    @property
    def total_s(self) -> float:
        return self.time_s * self.repeat

    @property
    def bottleneck_detail(self) -> str:
        """Finest attribution, e.g. 'ddr:load:expert_weight' or 'latency:softmax(sfu)'."""
        d: dict[str, float] = {}
        for k in self.kernels:
            for n, t in k.limiter_detail.items():
                d[n] = d.get(n, 0.0) + t
        return max(d.items(), key=lambda kv: kv[1])[0] if d else "-"

    @property
    def occupancy(self) -> str:
        """'resident/limiter' of the main kernel, e.g. '1/smem', '2/regs', '4/tmem'."""
        m = self.kernels[0].meta if self.kernels else {}
        if "resident" not in m:
            return "-"
        s = f"{m['resident']}/{m.get('occ_limiter', '?')}"
        if m.get("reg_spill_bytes"):
            s += "+spill"
        return s

    @property
    def bottleneck(self) -> str:
        lim: dict[str, float] = {}
        for k in self.kernels:
            for n, t in k.limiter_time.items():
                lim[n] = lim.get(n, 0.0) + t
        return max(lim.items(), key=lambda kv: kv[1])[0] if lim else "-"


@dataclass
class ModelReport:
    model: str
    hw: str
    rc: RunConfig
    ops: list[OpResult]
    memory: MemoryReport
    backend: str = backend.BACKEND
    notes: list[str] = field(default_factory=list)

    @property
    def step_time_s(self) -> float:
        return sum(o.total_s for o in self.ops)

    def limiter_breakdown(self) -> dict[str, float]:
        """Seconds per limiter over the whole step (tc, ddr, l2, sfu, latency, launch, net ...)."""
        out: dict[str, float] = {}
        for o in self.ops:
            for k in o.kernels:
                for n, t in k.limiter_time.items():
                    out[n] = out.get(n, 0.0) + t * o.repeat * o.exposed
        return dict(sorted(out.items(), key=lambda kv: -kv[1]))

    def detail_breakdown(self) -> dict[str, float]:
        """Seconds per fine-grained limiter: resource + tensor/action (ddr:load:kv_cache(K) ...)."""
        out: dict[str, float] = {}
        for o in self.ops:
            for k in o.kernels:
                for n, t in k.limiter_detail.items():
                    out[n] = out.get(n, 0.0) + t * o.repeat * o.exposed
        return dict(sorted(out.items(), key=lambda kv: -kv[1]))

    def by_category(self) -> dict[str, float]:
        out: dict[str, float] = {}
        for o in self.ops:
            cat = o.op.name.split(".")[-1]
            out[cat] = out.get(cat, 0.0) + o.total_s
        return dict(sorted(out.items(), key=lambda kv: -kv[1]))

    @property
    def tokens_per_s_per_gpu(self) -> float:
        toks = self.rc.batch if self.rc.phase == "decode" else self.rc.batch * self.rc.seq_len
        return toks / self.step_time_s / self.rc.world


def _override(rc: RunConfig, name: str) -> dict | None:
    for pat, fields in rc.tile_overrides.items():
        if fnmatch.fnmatch(name, pat):
            return fields
    return None


def _eval_all(kernels: list[Kernel], hw) -> list[KernelResult]:
    return [backend.evaluate(k, hw) for k in kernels]


def _best(cands, hw):
    best = None
    for tile, ks in cands:
        if ks is None:
            continue
        res = _eval_all(ks, hw)
        t = sum(r.time_s for r in res)
        if best is None or t < best[0]:
            best = (t, tile, res)
    return best


def resolve_op(op: Op, hw: HardwareSpec, rc: RunConfig) -> tuple[list[KernelResult], str]:
    p = op.p
    if op.kind == "gemm":
        ov = _override(rc, op.name)
        if ov is not None:
            tiles = [TileConfig(**ov)]
        elif rc.gemm_tile == "auto":
            tiles = gemm_search_space(p["M"], p["N"], p["K"])
        else:
            tiles = [TileConfig(**rc.gemm_tile)]
        cands = ((t, lower_gemm(hw, op.name, p["M"], p["N"], p["K"], batch=p["batch"], a_dtype=p["a_dtype"],
                                b_dtype=p["b_dtype"], c_dtype=p["c_dtype"], compute_dtype=p["compute_dtype"],
                                tile=t, names=tuple(p.get("names", ("act", "weight", "out"))))) for t in tiles)
        best = _best(cands, hw)
        if best is None:
            raise ValueError(f"{op.name}: no legal tile among {len(tiles)} candidates")
        return best[2], best[2][0].meta.get("tile", best[1].short())

    if op.kind in ("attn_decode", "attn_prefill"):
        ov = _override(rc, op.name)
        if ov is not None:
            tiles = [AttnTileConfig(**ov)]
        elif rc.attn_tile == "auto":
            tiles = attn_search_space()
        else:
            tiles = [AttnTileConfig(**rc.attn_tile)]
        kw = dict(B=p["B"], H=p["H"], kv_heads=p["kv_heads"], S=p["S"], d_qk=p["d_qk"], d_v=p["d_v"],
                  kv_dtype=rc.kv_dtype, compute_dtype=rc.attn_compute_dtype)
        if op.kind == "attn_decode":
            cands = ((t, lower_attention_decode(hw, op.name, v_in_k=p["v_in_k"], tile=t, **kw)) for t in tiles)
        else:
            cands = ((t, lower_attention_prefill(hw, op.name, tile=t, causal=p.get("causal", True),
                                                 window=p.get("window", 0), **kw)) for t in tiles)
        best = _best(cands, hw)
        if best is None:
            raise ValueError(f"{op.name}: no legal attention tile")
        return best[2], best[2][0].meta.get("tile", best[1].short())

    if op.kind == "elementwise":
        q = dict(p)
        if "names" in q:
            q["names"] = tuple(q["names"])
        return _eval_all(lower_elementwise(hw, op.name, **q), hw), "-"
    if op.kind == "allreduce":
        return _eval_all(comm.allreduce(hw, op.name, p["bytes"], p["group"]), hw), "-"
    if op.kind == "a2a":
        return _eval_all(comm.all_to_all(hw, op.name, p["bytes"], p["group"]), hw), "-"
    raise ValueError(op.kind)


def run_model(model: ModelSpec, hw: HardwareSpec, rc: RunConfig, progress=None) -> ModelReport:
    """progress(done, total, label) is called per op so UIs can show a processing state."""
    groups = lower_model(model, rc)
    results = []
    total = sum(len(ops) for _, _, ops in groups)
    done = 0
    for gname, rep, ops in groups:
        for op in ops:
            if progress:
                progress(done, total, op.name)
            done += 1
            ks, tile = resolve_op(op, hw, rc)
            ex = 1.0 - rc.comm_overlap if op.kind in ("allreduce", "a2a") else 1.0
            results.append(OpResult(op, gname, rep, ks, tile, ex))
    mem = memory_report(model, rc, groups, hw)
    rep = ModelReport(model.name, hw.name, rc, results, mem)
    if not mem.fits:
        rep.notes.append(f"DOES NOT FIT: needs {mem.total_GB:.1f} GB > {mem.capacity_GB:.1f} GB per GPU")
    return rep

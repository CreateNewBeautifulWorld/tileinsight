"""CLI.

  python -m tilesight.cli run   --model kimi_k2.hf --hw b300 --phase decode --batch 256 --seq 8192 --dp 8
  python -m tilesight.cli request --model kimi_k2.hf --hw b300 --batch 256 --dp 8 --prompt 8192 --output 4096
  python -m tilesight.cli sweep --model kimi_k2.hf --hw b300 --param memory.ddr.bandwidth_TBps --values 4,6,8,12,16
  python -m tilesight.cli need  --model kimi_k2.hf --hw b300 --param memory.ddr.bandwidth_TBps --target-ms 20
  python -m tilesight.cli dump-model --model kimi_k2.hf      # editable block-level YAML
  python -m tilesight.cli serve --host 0.0.0.0 --port 8000   # web UI; computation stays on this machine
"""
from __future__ import annotations

import argparse
import json

import yaml

from . import HardwareSpec, ModelSpec, RunConfig, run_model
from .dse.sweep import required_value, rows_to_csv, sweep
from .report.table import model_summary, ops_csv


def _rc(a) -> RunConfig:
    kw = {}
    if a.run_config:
        with open(a.run_config) as f:
            kw.update(yaml.safe_load(f))
    for k in ("phase", "batch", "tp", "dp", "ep", "weight_dtype", "expert_dtype", "kv_dtype", "compute_dtype",
              "page_size", "attn_impl"):
        v = getattr(a, k, None)
        if v is not None:
            kw[k] = v
    if a.seq is not None:
        kw["seq_len"] = a.seq
    if a.prompt is not None:
        kw["prompt_len"] = a.prompt
    if a.output is not None:
        kw["output_len"] = a.output
    if a.tile:
        kw["gemm_tile"] = json.loads(a.tile)
    return RunConfig(**kw)


def _hw(a) -> HardwareSpec:
    hw = HardwareSpec.load(a.hw)
    for s in a.set or []:
        k, v = s.split("=")
        hw = hw.override({k: yaml.safe_load(v)})
    return hw


def main(argv=None):
    ap = argparse.ArgumentParser("tilesight")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sp = sub.add_parser("serve")
    sp.add_argument("--host", default="127.0.0.1", help="0.0.0.0 to let other machines reach it")
    sp.add_argument("--port", type=int, default=8000)

    for name in ("run", "request", "sweep", "need", "dump-model"):
        p = sub.add_parser(name)
        p.add_argument("--model", required=True)
        p.add_argument("--hw", default="b300")
        p.add_argument("--run-config")
        p.add_argument("--phase")
        p.add_argument("--batch", type=int)
        p.add_argument("--seq", type=int)
        p.add_argument("--prompt", type=int, help="prompt length (request mode)")
        p.add_argument("--output", type=int, help="generated tokens per request (request mode)")
        p.add_argument("--page-size", dest="page_size", type=int)
        p.add_argument("--attn-impl", dest="attn_impl")
        p.add_argument("--tp", type=int)
        p.add_argument("--dp", type=int)
        p.add_argument("--ep", type=int)
        p.add_argument("--weight-dtype", dest="weight_dtype")
        p.add_argument("--expert-dtype", dest="expert_dtype")
        p.add_argument("--kv-dtype", dest="kv_dtype")
        p.add_argument("--compute-dtype", dest="compute_dtype")
        p.add_argument("--tile", help='fixed GEMM tile, JSON e.g. \'{"bm":128,"bn":256,"bk":64}\'')
        p.add_argument("--set", action="append", help="hw override path=value (repeatable)")
        p.add_argument("--csv")
        if name in ("sweep", "need"):
            p.add_argument("--param", required=True)
        if name == "sweep":
            p.add_argument("--values", required=True)
        if name == "need":
            p.add_argument("--target-ms", type=float, required=True)
            p.add_argument("--lo", type=float, default=1.0)
            p.add_argument("--hi", type=float, default=64.0)
    a = ap.parse_args(argv)
    if a.cmd == "serve":
        from .server import serve
        return serve(a.host, a.port)
    model = ModelSpec.load(a.model)
    if a.cmd == "dump-model":
        print(model.dump_yaml())
        return
    hw, rc = _hw(a), _rc(a)
    if a.cmd == "request":
        from .model.request import request_summary, run_request
        print(request_summary(run_request(model, hw, rc)))
        return
    if a.cmd == "run":
        rep = run_model(model, hw, rc)
        print(model_summary(rep))
        if a.csv:
            open(a.csv, "w").write(ops_csv(rep))
    elif a.cmd == "sweep":
        vals = [float(v) for v in a.values.split(",")]
        rows = sweep(model, hw, rc, a.param, vals)
        out = rows_to_csv(rows)
        print(out)
        if a.csv:
            open(a.csv, "w").write(out)
    elif a.cmd == "need":
        v = required_value(model, hw, rc, a.param, a.target_ms, a.lo, a.hi)
        print(f"{a.param} needed for step <= {a.target_ms} ms: {v if v is None else round(v, 3)}")


if __name__ == "__main__":
    main()

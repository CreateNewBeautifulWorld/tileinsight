"""Pure-Python reference engine (the C++ core in cpp/ must match it to 1e-9 rel).

Implements docs/DESIGN.md §3:

  wave decomposition : concurrent = SMs * resident; full waves + one tail wave
  per-SM share        : shared lanes get rate = min(total/active_SMs, per_sm_cap)
  steady round        : R = max( bps * max_r sum_o u_r(o) ,  CP / stages ,  CPrec / consumers )  (Eq. 4')
                        CP    = longest path through the iteration DAG, node weight
                                w(o) = max_r u_r(o) + lat(o)   (SMEM-buffer recycling recurrence:
                                load_i waits for the consumer of iteration i-stages)
                        CPrec = longest path through `recurrent` actions only
                                (loop-carried compute, overlapped by ping-pong consumers)
  wave time           : T = T_pro + T_fill + iters * R + T_epi             (Eq. 2')
                        T_fill = max(0, CP - R)  (first iteration's exposed latency)
  kernel time         : sum over waves + launch overhead
"""
from __future__ import annotations

import math

from ..hw.spec import HardwareSpec, Lane
from ..ir.kernel import Action, Kernel, KernelResult


def _u(a: Action, lane: Lane, active: int) -> float:
    w = a.work.get(lane.name, 0.0)
    if w == 0.0:
        return 0.0
    if lane.shared:
        rate = min(lane.total_rate / active, lane.per_sm_cap)
        return w / rate
    return w


def _node_w(a: Action, lanes: list[Lane], active: int) -> float:
    return max((_u(a, l, active) for l in lanes), default=0.0) + a.latency_s


def _longest_path(actions: list[Action], weights: list[float]) -> float:
    return _critical_path(actions, weights)[0]


def _critical_path(actions: list[Action], weights: list[float]) -> tuple[float, list[int]]:
    """Longest path (actions are in topological order) and its node indices."""
    n = len(actions)
    best, pred = [0.0] * n, [-1] * n
    for i, a in enumerate(actions):
        start, p = 0.0, -1
        for d in a.deps:
            if best[d] > start:
                start, p = best[d], d
        best[i], pred[i] = start + weights[i], p
    if n == 0:
        return 0.0, []
    end = max(range(n), key=lambda i: best[i])      # first max
    path = []
    while end >= 0:
        path.append(end)
        end = pred[end]
    return best[path[0]], path[::-1]


def _lane_detail(actions: list[Action], lane: Lane, active: int) -> str:
    """'lane:action' for the action putting the most work on `lane` (first max)."""
    best, arg = -1.0, 0
    for i, a in enumerate(actions):
        v = _u(a, lane, active)
        if v > best:
            best, arg = v, i
    return f"{lane.name}:{actions[arg].name}"


def _latency_detail(actions: list[Action], weights: list[float], lanes: list[Lane], active: int) -> str:
    """'latency:action(lane)' for the heaviest node on the critical path."""
    _, path = _critical_path(actions, weights)
    if not path:
        return "latency:none"
    j = max(path, key=lambda i: weights[i])          # first max in path order
    a = actions[j]
    best, lane = -1.0, "none"
    for l in lanes:
        v = _u(a, l, active)
        if v > best:
            best, lane = v, l.name
    if a.latency_s > best:
        lane = "mem-lat"
    return f"latency:{a.name}({lane})"


def _phase(actions: list[Action], lanes: list[Lane], active: int, bps: int) -> tuple[float, str, str]:
    """Non-looped phase (prologue/epilogue): max(resource bound, dependency chain)."""
    if not actions:
        return 0.0, "none", "none"
    sums = {l.name: bps * sum(_u(a, l, active) for a in actions) for l in lanes}
    lane, rb = max(sums.items(), key=lambda kv: kv[1])
    w = [_node_w(a, lanes, active) for a in actions]
    cp = _longest_path(actions, w)
    if rb >= cp:
        return rb, lane, _lane_detail(actions, next(l for l in lanes if l.name == lane), active)
    return cp, "latency", _latency_detail(actions, w, lanes, active)


def evaluate(k: Kernel, hw: HardwareSpec) -> KernelResult:
    lanes = hw.lanes()
    launch = hw.launch_s
    if k.fixed_time_s is not None:          # communication kernels
        return KernelResult(k.name, k.kind, k.fixed_time_s + launch, "net",
                            {"net": 1.0}, {"comm": k.fixed_time_s, "launch": launch},
                            {"net": k.fixed_time_s, "launch": launch}, 0, k.meta,
                            {f"net:{k.meta.get('algo', 'comm')}": k.fixed_time_s, "launch": launch})

    sms = hw.sms
    resident = max(1, k.resident)
    conc = sms * resident
    full, tail = divmod(k.num_blocks, conc)
    waves = [(conc, full)] if full else []
    if tail:
        waves.append((tail, 1))

    total = 0.0
    bd = {"prologue": 0.0, "fill": 0.0, "steady": 0.0, "epilogue": 0.0, "launch": launch}
    lim: dict[str, float] = {"launch": launch}
    det: dict[str, float] = {"launch": launch}

    for blocks, count in waves:
        active = min(sms, math.ceil(blocks / resident))
        bps = math.ceil(blocks / active)
        # steady-state round (one iteration of every resident block on an SM)
        sums = {l.name: bps * sum(_u(a, l, active) for a in k.body) for l in lanes}
        lane, rb = max(sums.items(), key=lambda kv: kv[1])
        w = [_node_w(a, lanes, active) for a in k.body]
        cp = _longest_path(k.body, w)
        w_rec = [wi if a.recurrent else 0.0 for a, wi in zip(k.body, w)]
        cp_rec = _longest_path(k.body, w_rec)
        lat_bound = max(cp / max(1, k.stages), cp_rec / max(1, k.consumers))
        if rb >= lat_bound:
            rnd, limiter = rb, lane
            d_steady = _lane_detail(k.body, next(l for l in lanes if l.name == lane), active)
        else:
            rnd, limiter = lat_bound, "latency"
            use_rec = cp_rec / max(1, k.consumers) > cp / max(1, k.stages)
            d_steady = _latency_detail(k.body, w_rec if use_rec else w, lanes, active)
        t_pro, l_pro, d_pro = _phase(k.prologue, lanes, active, bps)
        t_epi, l_epi, d_epi = _phase(k.epilogue, lanes, active, bps)
        t_fill = max(0.0, cp - rnd) if k.iters > 0 else 0.0
        t_steady = k.iters * rnd
        t_wave = t_pro + t_fill + t_steady + t_epi
        total += count * t_wave
        bd["prologue"] += count * t_pro
        bd["fill"] += count * t_fill
        bd["steady"] += count * t_steady
        bd["epilogue"] += count * t_epi
        for name, t in ((limiter, t_steady), ("latency", t_fill), (l_pro, t_pro), (l_epi, t_epi)):
            if t > 0:
                lim[name] = lim.get(name, 0.0) + count * t
        for name, t in ((d_steady, t_steady), ("latency:fill", t_fill), (d_pro, t_pro), (d_epi, t_epi)):
            if t > 0:
                det[name] = det.get(name, 0.0) + count * t

    total += launch

    # utilization: whole-machine busy fraction per lane
    util: dict[str, float] = {}
    for l in lanes:
        per_block = sum(a.work.get(l.name, 0.0) for a in k.prologue) + \
            k.iters * sum(a.work.get(l.name, 0.0) for a in k.body) + \
            sum(a.work.get(l.name, 0.0) for a in k.epilogue)
        busy = k.num_blocks * per_block
        busy = busy / l.total_rate if l.shared else busy / sms
        if busy > 0:
            util[l.name] = busy / total
    bottleneck = max(lim.items(), key=lambda kv: kv[1])[0]
    return KernelResult(k.name, k.kind, total, bottleneck, util, bd, lim,
                        len(waves) and (full + (1 if tail else 0)), k.meta, det)

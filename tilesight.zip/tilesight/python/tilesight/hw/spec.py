"""Hardware description.

The hardware is a plain nested dict loaded from YAML (see hw/db/*.yaml) so that
design-space experiments can override ANY field by dotted path, e.g.
    hw.override({"memory.ddr.bandwidth_TBps": 12.0})

`HardwareSpec.lanes()` turns the description into the resource lanes used by the
engine (docs/DESIGN.md §2).  Two kinds of lanes:
  * per-SM lanes   (tc, cuda, sfu, smem, tmem, path:<name>): action work is given in
    *seconds on one SM*; the lowering converts FLOPs/bytes to seconds with the
    helpers below.
  * shared lanes   (l2, ddr): action work is given in *bytes*; the engine divides by
    the per-SM share  min(total_rate / active_SMs, per_sm_cap).
Adding a new on-chip memory or load path to the YAML automatically adds a lane.
"""
from __future__ import annotations

import copy
import math
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml

DB_DIR = Path(__file__).parent / "db"

DTYPE_BYTES = {
    "fp4": 0.5, "nvfp4": 0.5, "mxfp4": 0.5, "int4": 0.5,
    "fp6": 0.75, "mxfp6": 0.75,
    "fp8": 1.0, "mxfp8": 1.0, "int8": 1.0,
    "bf16": 2.0, "fp16": 2.0,
    "tf32": 4.0, "fp32": 4.0,
}
# name -> the tensor-core datapath it runs on (hardware tables are keyed by these)
DTYPE_ALIAS = {"nvfp4": "fp4", "mxfp4": "fp4", "mxfp6": "fp6", "mxfp8": "fp8", "fp16": "fp16"}
# weight-only formats: weights are stored narrow, the MMA runs at the activation width
WEIGHT_ONLY = {"int4"}
# if a datapath is missing on a part, fall back to the next wider one
WIDEN = ["fp4", "fp6", "fp8", "int8", "bf16", "fp16", "tf32", "fp32"]


@dataclass(frozen=True)
class Lane:
    name: str
    shared: bool          # True -> work in bytes, bandwidth shared by active SMs
    total_rate: float     # bytes/s for shared lanes (whole GPU); unused for per-SM lanes
    per_sm_cap: float     # bytes/s max one SM can draw from a shared lane (inf if none)


class HardwareSpec:
    def __init__(self, raw: dict[str, Any]):
        self.raw = raw
        self._fp: str | None = None

    @property
    def fingerprint(self) -> str:
        """Content hash; kernels lowered for equal specs are cached across objects."""
        if self._fp is None:
            import hashlib
            import json
            self._fp = hashlib.sha1(json.dumps(self.raw, sort_keys=True).encode()).hexdigest()
        return self._fp

    # ---------------------------------------------------------------- loading
    @classmethod
    def load(cls, name_or_path: str) -> "HardwareSpec":
        p = Path(name_or_path)
        if not p.exists():
            p = DB_DIR / f"{name_or_path.lower()}.yaml"
        with open(p) as f:
            return cls(yaml.safe_load(f))

    def override(self, changes: dict[str, Any]) -> "HardwareSpec":
        """Return a copy with dotted-path fields replaced (used by DSE sweeps)."""
        raw = copy.deepcopy(self.raw)
        for path, value in changes.items():
            node = raw
            keys = path.split(".")
            for k in keys[:-1]:
                node = node.setdefault(k, {})
            node[keys[-1]] = value
        return HardwareSpec(raw)

    def get(self, path: str, default: Any = None) -> Any:
        node: Any = self.raw
        for k in path.split("."):
            if not isinstance(node, dict) or k not in node:
                return default
            node = node[k]
        return node

    # ---------------------------------------------------------------- basics
    @property
    def name(self) -> str:
        return self.raw["name"]

    @property
    def sms(self) -> int:
        return int(self.raw["sms"])

    @property
    def clock_hz(self) -> float:
        return float(self.raw.get("clock_ghz", 1.8)) * 1e9

    def eff(self, key: str) -> float:
        return float(self.get(f"efficiency.{key}", 1.0))

    @property
    def has_tmem(self) -> bool:
        return self.get("memory.onchip.tmem") is not None

    @property
    def launch_s(self) -> float:
        return float(self.get("runtime.launch_overhead_us", 2.0)) * 1e-6

    @property
    def ddr_capacity_bytes(self) -> float:
        return float(self.get("memory.ddr.capacity_GB")) * 1e9

    # ---------------------------------------------------------------- per-SM rate helpers
    def tc_datapath(self, dtype: str) -> str | None:
        """Resolve a dtype to a tensor-core datapath this part has, widening if needed."""
        d = DTYPE_ALIAS.get(dtype, dtype)
        table = self.get("compute.tc_dense_tflops") or {}
        if d in table:
            return d
        if d in WIDEN:                       # e.g. fp4 on Hopper -> fp8; int8 -> bf16
            for wider in WIDEN[WIDEN.index(d):]:
                if wider in table:
                    return wider
        return None

    def tc_time_per_sm(self, flops: float, dtype: str) -> float:
        """Seconds one SM needs for `flops` tensor-core FLOPs of `dtype` (bf16 if unknown)."""
        d = self.tc_datapath(dtype) or "bf16"
        table = self.get("compute.tc_dense_tflops")
        return flops / (table[d] * 1e12 * self.eff("tc") / self.sms)

    def mma_cost(self, flops: float, dtype: str) -> tuple[str, float]:
        """(lane, seconds-on-one-SM) for a matmul: the tensor core, or CUDA cores for
        datatypes this part has no tensor-core datapath for (e.g. fp32 on most GPUs)."""
        if self.tc_datapath(dtype) is None:
            return "cuda", self.cuda_time_per_sm(flops)
        return "tc", self.tc_time_per_sm(flops, dtype)

    def resolve_path(self, path: str) -> str:
        """Map a requested load path to one this part actually has (AMD has no TMA)."""
        paths = self.get("load_paths") or {}
        if path in paths:
            return path
        default = self.get("load_paths_default")
        if default in paths:
            return default
        return next(iter(paths), path)

    def cuda_time_per_sm(self, flops: float) -> float:
        return flops / (self.get("compute.cuda_fp32_tflops") * 1e12 * self.eff("cuda") / self.sms)

    def sfu_time_per_sm(self, ops: float) -> float:
        return ops / (self.get("compute.sfu_tops") * 1e12 * self.eff("sfu") / self.sms)

    def smem_time_per_sm(self, nbytes: float) -> float:
        bw = self.get("memory.onchip.smem.bytes_per_clk") * self.clock_hz * self.eff("smem")
        return nbytes / bw

    def tmem_time_per_sm(self, read_bytes: float, write_bytes: float) -> float:
        t = self.get("memory.onchip.tmem")
        if t is None:
            return 0.0
        return read_bytes / (t["read_TBps"] * 1e12) + write_bytes / (t["write_TBps"] * 1e12)

    def path_time_per_sm(self, path: str, nbytes: float) -> float:
        p = self.get(f"load_paths.{self.resolve_path(path)}")
        if p is None:
            return 0.0
        return nbytes / (p["per_sm_GBps"] * 1e9)

    def path_latency_s(self, path: str) -> float:
        return float(self.get(f"load_paths.{self.resolve_path(path)}.latency_ns", 800)) * 1e-9

    # ---------------------------------------------------------------- capacities
    @property
    def smem_per_sm(self) -> int:
        return int(self.get("memory.onchip.smem.capacity_KB") * 1024)

    @property
    def tmem_per_sm(self) -> int:
        return int(self.get("memory.onchip.tmem.capacity_KB", 0) * 1024)

    @property
    def l2_capacity_bytes(self) -> float:
        l2 = self.get("memory.l2")
        return float(l2.get("effective_capacity_MB", l2["capacity_MB"])) * 1024 * 1024

    @property
    def l2_assoc(self) -> int:
        return int(self.get("memory.l2.assoc", 16))

    @property
    def tc_min_m(self) -> int:
        return int(self.get("compute.tc_min_m", 64))

    # ---------------------------------------------------------------- lanes
    def lanes(self) -> list[Lane]:
        inf = math.inf
        out = [Lane("tc", False, 0, inf), Lane("cuda", False, 0, inf), Lane("sfu", False, 0, inf)]
        for mem in (self.get("memory.onchip") or {}):
            out.append(Lane(mem, False, 0, inf))
        for path in (self.get("load_paths") or {}):
            out.append(Lane(f"path:{path}", False, 0, inf))
        l2 = self.get("memory.l2")
        cap = float(l2.get("per_sm_max_GBps", 1e9)) * 1e9
        out.append(Lane("l2", True, l2["bandwidth_TBps"] * 1e12 * self.eff("l2"), cap))
        ddr = self.get("memory.ddr")
        out.append(Lane("ddr", True, ddr["bandwidth_TBps"] * 1e12 * self.eff("ddr"), cap))
        return out

    def __repr__(self) -> str:
        return f"HardwareSpec({self.name}, sms={self.sms}, ddr={self.get('memory.ddr.bandwidth_TBps')} TB/s)"

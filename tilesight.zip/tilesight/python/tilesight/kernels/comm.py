"""Collectives via the alpha-beta stage model (paper §3.6, Eq. 11).

Each collective is decomposed into stages; stage time = alpha (per hop) + bytes on the
bottleneck link / link bandwidth. Link = NVLink inside `network.nvlink.domain_size`,
scale-out NIC otherwise (hierarchical collectives are a TODO, docs/TASKS.md E3).
"""
from __future__ import annotations

import math

from ..hw.spec import HardwareSpec
from ..ir.kernel import Kernel


def _link(hw: HardwareSpec, group: int) -> tuple[float, float]:
    nv = hw.get("network.nvlink")
    if group <= int(nv["domain_size"]):
        return nv["alpha_us"] * 1e-6, nv["bandwidth_GBps"] * 1e9
    so = hw.get("network.scaleout")
    return so["alpha_us"] * 1e-6, so["bandwidth_GBps"] * 1e9


def allreduce(hw: HardwareSpec, name: str, nbytes: float, group: int, algo: str = "auto") -> list[Kernel]:
    if group <= 1 or nbytes <= 0:
        return []
    a, bw = _link(hw, group)
    ring = 2 * (group - 1) * a + 2 * (group - 1) / group * nbytes / bw
    rd = math.ceil(math.log2(group)) * (a + nbytes / bw)              # recursive doubling
    if algo == "auto":
        t, algo = min((ring, "ring"), (rd, "recursive_doubling"))
    else:
        t = ring if algo == "ring" else rd
    return [Kernel(name, "comm", 0, 0, 1, 1, [], meta=dict(bytes=nbytes, group=group, algo=algo), fixed_time_s=t)]


def all_to_all(hw: HardwareSpec, name: str, send_bytes: float, group: int) -> list[Kernel]:
    """send_bytes = bytes this GPU sends in total (to all peers)."""
    if group <= 1 or send_bytes <= 0:
        return []
    a, bw = _link(hw, group)
    t = a * math.ceil(math.log2(group)) + send_bytes * (group - 1) / group / bw
    return [Kernel(name, "comm", 0, 0, 1, 1, [], meta=dict(bytes=send_bytes, group=group, algo="a2a"), fixed_time_s=t)]

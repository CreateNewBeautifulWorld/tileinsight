"""GEMM / batched GEMM / grouped (MoE) GEMM -> Kernel lowering.

C[b] (M x N) = A[b] (M x K) @ B[b] (K x N)    for b in range(batch)
  * dense linear      : batch=1
  * batched (per-head): batch=H           (MLA absorbed W_UK / W_UV)
  * grouped (MoE)     : batch=#active experts, M = tokens per active expert
Tile config -> grid, K-loop, occupancy, per-iteration action vector, L2 misses.
"""
from __future__ import annotations

import math

from ..hw.spec import DTYPE_BYTES, HardwareSpec
from ..ir.kernel import Action, Kernel
from ..engine import backend
from .tiles import TileConfig, parse_path_split


# ----------------------------------------------------------------------------- helpers
def gload(hw: HardwareSpec, name: str, nbytes: float, miss: float, load_path: str,
          deps: list[int] | None = None) -> Action:
    """Global -> SMEM tile load through one or more load paths (extended-HW §4.1)."""
    work = {"l2": nbytes, "ddr": nbytes * miss}
    lat = 0.0
    for path, frac in parse_path_split(load_path).items():
        real = hw.resolve_path(path)                 # AMD parts have no TMA: fall back to their path
        work[f"path:{real}"] = work.get(f"path:{real}", 0.0) + hw.path_time_per_sm(real, nbytes * frac)
        lat = max(lat, hw.path_latency_s(real))
    lat += (1 - miss) * hw.get("memory.l2.latency_ns") * 1e-9 + miss * hw.get("memory.ddr.latency_ns") * 1e-9
    return Action(name, work, deps or [], latency_s=lat)


def gstore(name: str, nbytes: float, deps: list[int] | None = None) -> Action:
    return Action(name, {"l2": nbytes, "ddr": nbytes}, deps or [])


BASE_REGS = 40            # per-thread registers for addresses, loop state, softmax scalars  [calib]


def reg_estimate(hw: HardwareSpec, acc_bytes: int, threads: int) -> tuple[int, int]:
    """(registers per thread, spilled bytes per block) for register-resident accumulators.

    On TMEM parts (Blackwell) the accumulator lives in TMEM, so only BASE_REGS plus an
    epilogue fragment is needed. On Hopper-class parts the fp32 accumulator is spread over
    the consumer threads' registers."""
    max_rpt = int(hw.get("occupancy.max_regs_per_thread", 255))
    acc_regs = 0 if hw.has_tmem else -(-acc_bytes // (4 * threads))
    rpt = BASE_REGS + acc_regs + (16 if hw.has_tmem else 0)
    spill = max(0, rpt - max_rpt) * 4 * threads
    return min(rpt, max_rpt), spill


def occupancy(hw: HardwareSpec, smem_bytes: int, acc_bytes: int, threads: int = 256) -> tuple[int, str]:
    """(resident blocks per SM, limiting resource).  limiter ∈ max_blocks|smem|threads|tmem|regs."""
    rpt, _ = reg_estimate(hw, acc_bytes, threads)
    lim = [("max_blocks", int(hw.get("occupancy.max_blocks_per_sm", 32))),
           ("smem", hw.smem_per_sm // max(1, smem_bytes)),
           ("threads", int(hw.get("occupancy.max_threads_per_sm", 2048)) // threads),
           ("regs", int(hw.get("occupancy.regs_per_sm", 65536)) // max(1, rpt * threads))]
    if hw.has_tmem:
        lim.append(("tmem", hw.tmem_per_sm // max(1, acc_bytes)))
    val = min(v for _, v in lim)
    name = "+".join(n for n, v in lim if v == val)       # every resource binding at the minimum
    return max(0, val), name


def grouped_raster(mt: int, nt: int, group_m: int):
    """Triton-style GROUP_M swizzle: yields (m, n) in issue order."""
    group_m = max(1, min(group_m, mt))
    for g0 in range(0, mt, group_m):
        rows = min(group_m, mt - g0)
        for n in range(nt):
            for r in range(rows):
                yield g0 + r, n


# ----------------------------------------------------------------------------- GEMM
_CACHE: dict = {}


def lower_gemm(hw: HardwareSpec, name: str, M: int, N: int, K: int, *, batch: int = 1,
               a_dtype="bf16", b_dtype="bf16", c_dtype="bf16", compute_dtype="bf16",
               tile: TileConfig = TileConfig(), names: tuple[str, str, str] = ("act", "weight", "out")
               ) -> list[Kernel] | None:
    """Returns the kernel list (GEMM [+ split-K reduce]) or None if the tile is illegal.
    `names` = tensor labels of (A, B, C) used in bottleneck attribution."""
    key = (hw.fingerprint, name, M, N, K, batch, a_dtype, b_dtype, c_dtype, compute_dtype, tile, names)
    if key not in _CACHE:
        _CACHE[key] = _lower_gemm(hw, name, M, N, K, batch, a_dtype, b_dtype, c_dtype, compute_dtype, tile, names)
    return _CACHE[key]


def _lower_gemm(hw, name, M, N, K, batch, a_dt, b_dt, c_dt, comp_dt, t: TileConfig, names=("act", "weight", "out")):
    an, bn_, cn = names
    if M <= 0 or N <= 0 or K <= 0 or batch <= 0:
        return []
    ab, bb, cb = DTYPE_BYTES[a_dt], DTYPE_BYTES[b_dt], DTYPE_BYTES[c_dt]
    mt, nt, kt = math.ceil(M / t.bm), math.ceil(N / t.bn), math.ceil(K / t.bk)
    sk = max(1, min(t.split_k, kt))
    iters = math.ceil(kt / sk)
    a_tile, b_tile = t.bm * t.bk * ab, t.bn * t.bk * bb
    cl = max(1, t.cluster_m)
    if cl > 1 and (mt < cl or not hw.get("compute.cluster_multicast", False)
                   or (t.cta_pair and (cl != 2 or not hw.get("compute.cta_pair", False)))):
        return None      # AMD parts have no thread-block clusters / TMA multicast
    stage = int(a_tile + (b_tile / cl if t.cta_pair else b_tile))
    epi_smem = int(t.bm * t.bn * cb)
    stages = t.stages or min(8, (hw.smem_per_sm - epi_smem) // stage)
    if stages < 2 or stages * stage + epi_smem > hw.smem_per_sm:
        return None
    acc = t.bm * t.bn * 4
    threads = 128 * (1 + (2 if t.bm >= 128 else 1))     # producer WG + consumer WG(s)
    resident, occ_lim = occupancy(hw, stages * stage + epi_smem, acc, threads)
    if resident < 1:
        return None
    rpt, spill = reg_estimate(hw, acc, threads - 128)
    blocks = batch * mt * nt * sk

    # ---- L2 model over the first wave (sampled K steps) ------------------------------
    conc = hw.sms * resident
    order = []
    for b in range(batch):
        for s in range(sk):
            for m, n in grouped_raster(mt, nt, t.swizzle):
                order.append((b, s, m, n))
                if len(order) >= conc:
                    break
            if len(order) >= conc:
                break
        if len(order) >= conc:
            break
    keys, streams = [], []
    for kk in range(min(iters, 4)):
        for (b, s, m, n) in order:
            k = s * iters + kk
            keys.append(((b * 4096 + m) * 65536 + k) * 2)          # A(b,m,k)
            streams.append(0)
            keys.append(((b * 4096 + n) * 65536 + k) * 2 + 1)      # B(b,n,k)
            streams.append(1)
    cap_tiles = hw.l2_capacity_bytes / ((a_tile + b_tile) / 2)
    mA, mB = backend.expected_misses(keys, streams, 2, hw.l2_assoc, cap_tiles)
    nacc = len(keys) / 2
    fa, fb = mA / nacc, mB / nacc

    # ---- actions --------------------------------------------------------------------
    bm_c = max(t.bm, hw.tc_min_m)                 # tensor-core M padding
    mma_lane, mma_t = hw.mma_cost(2 * bm_c * t.bn * t.bk, comp_dt)
    body = [
        gload(hw, f"load:{an}", a_tile, fa, t.load_path),
        # cluster_m CTAs along M share one B tile via TMA multicast (L2 traffic / cl);
        # with 2-CTA MMA (tcgen05 cta_group::2) each CTA also stores/reads only half of B.
        gload(hw, f"load:{bn_}", b_tile / cl, fb, t.load_path),
        Action("mma", {mma_lane: mma_t,
                       "smem": hw.smem_time_per_sm(a_tile + (b_tile / cl if t.cta_pair else b_tile))}, [0, 1]),
    ]
    if spill:   # register spill: accumulator fragments round-trip through local memory (L1/L2)
        body.append(Action("spill:regs", {"l2": 2.0 * spill / max(1, iters)}, [2]))
    out_bytes = t.bm * t.bn * (4 if sk > 1 else cb)
    epilogue = [
        Action("acc_read" if hw.has_tmem else "acc_regs",
               {"tmem": hw.tmem_time_per_sm(acc, 0), "cuda": hw.cuda_time_per_sm(2 * t.bm * t.bn)}),
        gstore(f"store:{cn if sk == 1 else 'partials'}", out_bytes, [0]),
    ]
    useful = 2.0 * M * N * K * batch
    meta = dict(M=M, N=N, K=K, batch=batch, tile=t.with_(stages=stages).short(), stages=stages, resident=resident,
                flops=useful, pad_eff=useful / (2.0 * batch * mt * t.bm * nt * t.bn * kt * t.bk),
                weight_bytes=K * N * bb * batch, l2_miss_A=fa, l2_miss_B=fb,
                dtype=f"{a_dt}x{b_dt}->{comp_dt}", occ_limiter=occ_lim, regs_per_thread=rpt,
                reg_spill_bytes=spill, smem_per_block=int(stages * stage + epi_smem),
                stages_limiter="smem" if not t.stages else "config")
    ks = [Kernel(name, "gemm", blocks, iters, stages, resident, body, [], epilogue, meta)]
    if sk > 1:
        ks += lower_elementwise(hw, f"{name}.splitk_reduce", bytes_in=sk * M * N * 4 * batch,
                                bytes_out=M * N * cb * batch, flops=sk * M * N * batch,
                                names=("partials", cn))
    return ks


# ----------------------------------------------------------------------------- elementwise
def lower_elementwise(hw: HardwareSpec, name: str, *, bytes_in: float, bytes_out: float,
                      flops: float = 0.0, sfu_ops: float = 0.0, kind: str = "elementwise",
                      chunk: int = 32 * 1024, names: tuple[str, str] = ("act", "act")) -> list[Kernel]:
    if bytes_in + bytes_out <= 0:
        return []
    blocks = max(1, math.ceil(max(bytes_in, bytes_out) / chunk))
    per = 1.0 / blocks
    body = [
        gload(hw, f"load:{names[0]}", bytes_in * per, 1.0, "lsu"),
        Action("compute", {"cuda": hw.cuda_time_per_sm(flops * per), "sfu": hw.sfu_time_per_sm(sfu_ops * per)}, [0]),
        gstore(f"store:{names[1]}", bytes_out * per, [1]),
    ]
    meta = dict(bytes=bytes_in + bytes_out, flops=flops, occ_limiter="-")
    return [Kernel(name, kind, blocks, 1, 1, 8, body, [], [], meta)]

"""Request-level runs (prompt/output, peak memory) and fine-grained bound attribution."""
from dataclasses import replace

from tilesight import HardwareSpec, ModelSpec, RunConfig, run_model
from tilesight.kernels.gemm import lower_gemm, occupancy
from tilesight.kernels.tiles import TileConfig
from tilesight.engine import reference
from tilesight.model.memory import kv_bytes_per_seq_all
from tilesight.model.request import run_request
from tilesight.report.table import resource_class

B300, H200 = HardwareSpec.load("b300"), HardwareSpec.load("h200")
KIMI = ModelSpec.load("kimi_k2.hf")


def test_tpot_grows_with_kv_and_peak_is_prompt_plus_output():
    rc = RunConfig(batch=64, dp=8, prompt_len=4000, output_len=2000, page_size=64, prefill_batch=8)
    r = run_request(KIMI, B300, rc)
    assert r.points[-1].tpot_s > r.points[0].tpot_s
    assert r.points[0].tpot_s <= r.tpot_avg_s <= r.points[-1].tpot_s
    exp = kv_bytes_per_seq_all(KIMI, rc, 6016) * rc.seqs_per_rank / 1e9   # ceil(6000/64)*64
    assert abs(r.peak_kv_GB - exp) < 1e-9
    assert abs(r.e2e_s - (r.ttft_s + r.tpot_avg_s * 2000)) < 1e-9


def test_avg_tpot_matches_dense_sampling():
    rc = RunConfig(batch=64, dp=8, prompt_len=2048, output_len=1024, prefill_batch=8)
    coarse = run_request(KIMI, B300, replace(rc, decode_samples=3))
    fine = run_request(KIMI, B300, replace(rc, decode_samples=9))
    assert abs(coarse.tpot_avg_s - fine.tpot_avg_s) / fine.tpot_avg_s < 0.01


def test_longer_output_needs_more_memory_fewer_requests():
    a = run_request(KIMI, B300, RunConfig(batch=64, dp=8, prompt_len=8192, output_len=1024, prefill_batch=8))
    b = run_request(KIMI, B300, RunConfig(batch=64, dp=8, prompt_len=8192, output_len=32768, prefill_batch=8))
    assert b.peak_kv_GB > a.peak_kv_GB and b.max_requests_per_rank < a.max_requests_per_rank


def test_detail_attributes_tensor():
    rep = run_model(KIMI, B300, RunConfig(phase="decode", batch=256, seq_len=8192, dp=8))
    det = rep.detail_breakdown()
    assert next(iter(det)) == "ddr:load:expert_weight"
    assert any(k.startswith("ddr:load:kv_cache") for k in det)
    # details refine the coarse limiter: totals agree
    assert abs(sum(det.values()) - sum(rep.limiter_breakdown().values())) < 1e-12


def test_naive_softmax_bound_on_scores_tensor():
    rc = RunConfig(phase="prefill", batch=1, seq_len=16384, tp=8, dp=1, attn_impl="naive")
    rep = run_model(ModelSpec.load("llama3_70b.hf"), B300, rc)
    sm = next(o for o in rep.ops if o.op.name.endswith("attn_softmax"))
    assert sm.bottleneck_detail.startswith("ddr:") and ("scores" in sm.bottleneck_detail or "probs" in sm.bottleneck_detail)


def test_register_limited_occupancy_on_hopper():
    # 128x256 fp32 accumulator in registers (no TMEM) -> regs bind on H200, not on B300
    r_h, lim_h = occupancy(H200, 1024, 128 * 256 * 4, 384)
    r_b, lim_b = occupancy(B300, 1024, 128 * 256 * 4, 384)
    assert "regs" in lim_h and "regs" not in lim_b


def test_register_spill_is_charged():
    ks = lower_gemm(H200, "g", 4096, 4096, 4096, tile=TileConfig(bm=128, bn=256, bk=64, stages=2))
    k = ks[0]
    # 128x256 fp32 over 256 consumer threads = 128 acc regs + base: fits in 255, no spill
    assert k.meta["reg_spill_bytes"] == 0 and k.meta["regs_per_thread"] <= 255
    assert "regs" in k.meta["occ_limiter"]


def test_resource_class_parsing():
    assert resource_class("ddr:load:expert_weight") == "memory:DDR/HBM"
    assert resource_class("latency:load:kv_cache(K)(mem-lat)") == "latency<-mem-lat"
    assert resource_class("latency:softmax(sfu)") == "latency<-sfu"
    assert resource_class("smem:mma") == "on-chip:smem"
